<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - I-go Homestay</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        footer {
            text-align: center;
            margin-top: 50px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Privacy Policy</h1>
    <p>
        At I-go Homestay, we value your privacy and are committed to protecting your personal information. This Privacy Policy outlines how we collect, use, and safeguard your data when you use our services.
    </p>

    <h2>Information We Collect</h2>
    <p>
        We may collect the following types of information:
    </p>
    <ul>
        <li>Personal Information: Name, email address, phone number, and billing information.</li>
        <li>Usage Data: Details about your interactions with our website, such as IP address, browser type, and pages visited.</li>
    </ul>

    <h2>How We Use Your Information</h2>
    <p>
        The information we collect is used for the following purposes:
    </p>
    <ul>
        <li>To provide and manage our services.</li>
        <li>To communicate with you, including sending booking confirmations and updates.</li>
        <li>To improve our website and services.</li>
        <li>To comply with legal obligations.</li>
    </ul>

    <h2>How We Protect Your Information</h2>
    <p>
        We implement a variety of security measures to maintain the safety of your personal information. These measures include encryption, secure servers, and access controls.
    </p>

    <h2>Sharing Your Information</h2>
    <p>
        We do not sell, trade, or otherwise transfer your personal information to outside parties, except as necessary to provide our services or comply with the law.
    </p>

    <h2>Your Rights</h2>
    <p>
        You have the right to access, update, or delete your personal information. To exercise these rights, please contact us at <a href="mailto:support@igo-homestay.com">support@igo-homestay.com</a>.
    </p>

    <h2>Changes to This Policy</h2>
    <p>
        We may update this Privacy Policy from time to time. Any changes will be posted on this page with the updated date.
    </p>

    <p>
        Last updated: <?php echo date('F d, Y'); ?>
    </p>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> I-go Homestay. All rights reserved.</p>
    </footer>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
