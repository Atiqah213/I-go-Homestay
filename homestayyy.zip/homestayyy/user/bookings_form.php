<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Error: User is not logged in.");
}

$user_id = $_SESSION['user_id'];

// Check if room_id is passed
if (!isset($_GET['room_id'])) {
    die("Error: Room ID is missing.");
}

$room_id = $_GET['room_id'];

// Fetch room details
$room = [];
try {
    $stmt = $conn->prepare("SELECT * FROM rooms WHERE room_id = :room_id");
    $stmt->execute(['room_id' => $room_id]);
    $room = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$room) {
        die("Error: Room not found.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_name = $_POST['customer_name'];
    $customer_email = $_POST['customer_email'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    $price_per_night = $room['price_per_night'];
    $status = 'Pending';

    // Calculate total price
    $check_in_date = new DateTime($check_in);
    $check_out_date = new DateTime($check_out);
    $interval = $check_in_date->diff($check_out_date);
    $total_price = $price_per_night * $interval->days;

    try {
        // Insert booking into database
        $stmt = $conn->prepare("INSERT INTO bookings (room_id, user_id, customer_email, check_in, check_out, total_price, status) 
                                VALUES (:room_id, :user_id, :customer_email, :check_in, :check_out, :total_price, :status)");
        $stmt->execute([
            'room_id' => $room_id,
            'user_id' => $user_id,
            'customer_email' => $customer_email,
            'check_in' => $check_in,
            'check_out' => $check_out,
            'total_price' => $total_price,
            'status' => $status,
        ]);

        echo "<script>alert('Booking successful!'); window.location.href = 'bookings.php';</script>";
        exit;
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form - I-go Homestay</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
		/* Navbar Styling */
        .navbar-brand img {
            height: 50px;
        }
        .navbar {
            background-color: #343a40;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: #ddd !important;
            font-weight: bold;
        }
        .nav-link:hover {
            color: #fff !important;
        }
		/* Background Styling */
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('../uploads/mainbg.jpg') no-repeat center center;
            background-size: cover;
            color: #fff;
        }
        .booking-form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .booking-form {
            background-color: #aaa;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 800px;
        }
        .form-control, .btn-primary {
            border-radius: 25px;
        }
        .btn-primary {
            font-weight: bold;
        }
        .form-section-title {
            font-weight: bold;
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="../homepage.php">
            <img src="../uploads/I-go_logo.jpg" alt="I-go Logo">
            <b><span class="ml-2">I-go Homestay</span></b>
        </a>
        <div class="ml-auto d-flex">
            <a class="nav-link" href="user_dashboard.php">Home</a>
            <a class="nav-link" href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="booking-form-container">
    <form class="booking-form" method="POST">
        <h3 class="form-section-title">Booking Details</h3>
        <div class="row">
            <!-- Customer Details -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="customer_name">Name</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name" placeholder="Your Name" required>
                </div>
                <div class="form-group">
                    <label for="customer_email">Email</label>
                    <input type="email" class="form-control" id="customer_email" name="customer_email" placeholder="Your Email" required>
                </div>
            </div>
            <!-- Room Details -->
            <div class="col-md-6">
                <div class="form-group">
                    <label for="check_in">Check-In</label>
                    <input type="date" class="form-control" id="check_in" name="check_in" required>
                </div>
                <div class="form-group">
                    <label for="check_out">Check-Out</label>
                    <input type="date" class="form-control" id="check_out" name="check_out" required>
                </div>
                <div class="form-group">
                    <label>Price per Night</label>
                    <input type="text" class="form-control" value="RM<?php echo number_format($room['price_per_night'], 2); ?>" readonly>
                </div>
                <button type="submit" class="btn btn-primary btn-block mt-4">Reserve</button>
            </div>
        </div>
    </form>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
