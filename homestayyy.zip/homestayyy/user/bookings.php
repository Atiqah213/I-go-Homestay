<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Error: User is not logged in.");
}

$user_id = $_SESSION['user_id'];

// Fetch all bookings for the logged-in user
$bookings = [];
try {
    $stmt = $conn->prepare("SELECT b.*, r.room_name 
                            FROM bookings b 
                            JOIN rooms r ON b.room_id = r.room_id 
                            WHERE b.user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Fetch all rooms for "Book Now" functionality
$rooms = [];
try {
    $stmt = $conn->prepare("SELECT * FROM rooms WHERE availability = 1");
    $stmt->execute();
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Bookings - I-go Homestay</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Navbar Styling */
        .navbar-brand img {
            height: 50px;
        }
        .navbar {
            background-color: #343a40;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: #ddd !important;
            font-weight: bold;
        }
        .nav-link:hover {
            color: #fff !important;
        }
        .nav-item {
            margin-left: 20px;
        }

        /* Background Styling */
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('../uploads/mainbg.jpg') no-repeat center center;
            background-size: cover;
            color: #b4c2d1;
        }

        /* Table and Card Styling */
        .table thead {
            background-color: #9099a3;
            color: #343a40;
        }
        .table-striped tbody tr:nth-child(odd) {
            background-color: #f1f1f1;
        }
        .table-striped tbody tr:nth-child(even) {
            background-color: #ffffff;
        }
        .table td, .table th {
            vertical-align: middle;
            padding: 12px 15px;
        }

        /* Card Styling */
        .card {
            background: rgba(163, 118, 141, 0.8);
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(163, 118, 141, 0.8);
        }
        .btn-block {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .alert {
            font-weight: bold;
        }

        /* Button Styling */
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="../homepage.php">
            <img src="../uploads/I-go_logo.jpg" alt="I-go Logo">
            <b><span class="ml-2">I-go Homestay</span></b>
        </a>
        <div class="ml-auto d-flex">
            <a class="nav-link" href="user_dashboard.php">Home</a>
            <a class="nav-link" href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h3 class="text-center text-light">Your Bookings</h3>

    <!-- Bookings Table -->
    <div class="table-responsive mt-4">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Room Name</th>
                    <th>Check-In</th>
                    <th>Check-Out</th>
                    <th>Total Price</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($bookings)): ?>
                    <?php foreach ($bookings as $booking): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($booking['booking_id']); ?></td>
                            <td><?php echo htmlspecialchars($booking['room_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['check_in']); ?></td>
                            <td><?php echo htmlspecialchars($booking['check_out']); ?></td>
                            <td>RM<?php echo number_format($booking['total_price'], 2); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-primary status-update"
                                            data-booking-id="<?php echo $booking['booking_id']; ?>"
                                            data-status="Reserved">Reserved</button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center text-light">No bookings found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Rooms Table for Booking -->
    <h3 class="mt-5 text-center text-light">Available Rooms</h3>
    <div class="table-responsive mt-4">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Room ID</th>
                    <th>Room Name</th>
                    <th>Price per Night</th>
                    <th>Capacity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($rooms)): ?>
                    <?php foreach ($rooms as $room): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($room['room_id']); ?></td>
                            <td><?php echo htmlspecialchars($room['room_name']); ?></td>
                            <td>RM<?php echo number_format($room['price_per_night'], 2); ?></td>
                            <td><?php echo htmlspecialchars($room['capacity']); ?> person(s)</td>
                            <td>
                                <form method="GET" action="bookings_form.php">
                                    <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                                    <button type="submit" class="btn btn-primary btn-sm">Book Now!</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center text-light">No rooms available for booking.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
