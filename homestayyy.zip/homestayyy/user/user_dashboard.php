<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Fetch all rooms with their images
$rooms = [];
try {
    $stmt = $conn->prepare("SELECT * FROM rooms");
    $stmt->execute();
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - View Rooms</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
		
        /* General styles */
        body {
            background-color: #f5f5f5;
        }
        .navbar {
            background-color: #343a40 !important;
        }
        .navbar-brand {
            color: #fff !important;
        }
        .navbar-brand:hover {
            color: #f8f9fa !important;
        }
        .nav-link {
            color: #ddd !important;
        }
        .nav-link:hover {
            color: #fff !important;
        }
		
        .carousel-inner img {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }

        .card {
            transition: transform 0.3s, box-shadow 0.3s;
            border: none;
            border-radius: 8px;
        }
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .card-title {
            font-weight: bold;
            color: #343a40;
        }

        .modal-header {
            background-color: #007bff;
            color: #fff;
        }

        .facility-list li {
            list-style: none;
            margin-bottom: 10px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        /* Effect for carousel indicators */
        .carousel-indicators li {
            background-color: #007bff;
        }

        .carousel-indicators .active {
            background-color: #0056b3;
        }
		/* Footer Styling */
        footer {
            background-color: #343a40;
            color: #ddd;
            padding: 10px 0;
            text-align: center;
        }
        footer a {
            color: #007bff;
            text-decoration: none;
        }
        footer a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
	
	
        <a class="navbar-brand" href="#">
            <img src="../uploads/I-go_logo.jpg" alt="I-go Logo" style="height: 40px;">
            <span class="ml-2">I-go Homestay</span>
        </a>
       <div class="ml-auto d-flex">
            <a class="nav-link" href="review_and_report.php">Reviews</a>
            <a class="nav-link" href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h3 class="mb-4 text-center">Discover Our Rooms</h3>

    <div class="row">
        <?php if (!empty($rooms)): ?>
            <?php foreach ($rooms as $room): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <!-- Room Images Carousel -->
                        <?php
                        $stmt = $conn->prepare("SELECT * FROM room_images WHERE room_id = :room_id");
                        $stmt->execute(['room_id' => $room['room_id']]);
                        $images = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        <div id="carousel-<?php echo $room['room_id']; ?>" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <?php if (!empty($images)): ?>
                                    <?php foreach ($images as $index => $image): ?>
                                        <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                            <img src="../uploads/<?php echo htmlspecialchars($image['image_path']); ?>" class="d-block w-100" alt="Room Image">
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="carousel-item active">
                                        <img src="../uploads/default.jpg" class="d-block w-100" alt="Default Image">
                                    </div>
                                <?php endif; ?>
                            </div>
                            <a class="carousel-control-prev" href="#carousel-<?php echo $room['room_id']; ?>" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carousel-<?php echo $room['room_id']; ?>" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>

                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($room['room_name']); ?></h5>
                            <p class="card-text">Price: <strong>RM<?php echo number_format($room['price_per_night'], 2); ?></strong> per night</p>
                            <p class="card-text">Capacity: <?php echo htmlspecialchars($room['capacity']); ?> person(s)</p>
                            <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#roomModal-<?php echo $room['room_id']; ?>">
                                View Details
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Room Details Modal -->
                <div class="modal fade" id="roomModal-<?php echo $room['room_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="roomModalLabel-<?php echo $room['room_id']; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="roomModalLabel-<?php echo $room['room_id']; ?>"><?php echo htmlspecialchars($room['room_name']); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div id="modalCarousel-<?php echo $room['room_id']; ?>" class="carousel slide" data-ride="carousel">
                                    <div class="carousel-inner">
                                        <?php foreach ($images as $index => $image): ?>
                                            <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                                <img src="../uploads/<?php echo htmlspecialchars($image['image_path']); ?>" class="d-block w-100" alt="Room Image">
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <a class="carousel-control-prev" href="#modalCarousel-<?php echo $room['room_id']; ?>" role="button" data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#modalCarousel-<?php echo $room['room_id']; ?>" role="button" data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                                <hr>
                                <h5>Description</h5>
                                <p><?php echo htmlspecialchars($room['description']); ?></p>
                                <h5>Details</h5>
                                <ul>
                                    <li><i class="fas fa-bed"></i> Capacity: <?php echo htmlspecialchars($room['capacity']); ?> person(s)</li>
                                    <li><i class="fas fa-money-bill-wave"></i> Price: RM<?php echo number_format($room['price_per_night'], 2); ?> per night</li>
                                    <li><i class="fas fa-check-circle"></i> Availability: <?php echo $room['availability'] ? 'Available' : 'Not Available'; ?></li>
                                </ul>
                                <h5>Facilities</h5>
                                <ul class="facility-list">
                                    <li><i class="fas fa-wifi"></i> Free WiFi</li>
                                    <li><i class="fas fa-tv"></i> Flat-screen TV</li>
                                    <li><i class="fas fa-snowflake"></i> Air conditioning</li>
                                    <li><i class="fas fa-bath"></i> Private bathroom</li>
                                    <li><i class="fas fa-utensils"></i> Kitchenette</li>
                                </ul>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								<a href="bookings.php?room_id=<?php echo $room['room_id']; ?>" class="btn btn-primary btn-sm">Book Now!</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <p class="text-center">No rooms available.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Footer -->
<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> I-go Homestay. All rights reserved. | <a href="privacy-policy.php">Privacy Policy</a></p>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
