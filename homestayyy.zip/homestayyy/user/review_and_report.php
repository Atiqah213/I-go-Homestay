<?php
session_start();
include '../db.php'; // Include your database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success_message = "";
$error_message = "";

// Handle Review Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_review'])) {
    $rating = intval($_POST['rating']);
    $comment = trim($_POST['review_comment']);

    if ($rating >= 1 && $rating <= 5 && !empty($comment)) {
        try {
            $stmt = $conn->prepare("INSERT INTO reviews (user_id, rating, comment) VALUES (:user_id, :rating, :comment)");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':rating', $rating);
            $stmt->bindParam(':comment', $comment);
            $stmt->execute();
            $success_message = "Review submitted successfully!";
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    } else {
        $error_message = "Please provide a valid rating (1-5) and a comment.";
    }
}

// Fetch all reviews to display
try {
    $stmt = $conn->prepare("SELECT r.rating, r.comment, r.created_at, u.username 
                            FROM reviews r 
                            JOIN user u ON r.user_id = u.user_id 
                            ORDER BY r.created_at DESC");
    $stmt->execute();
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = "Error fetching reviews: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review and Report</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Navbar Styling */
        .navbar-brand img {
            height: 50px;
        }
        .navbar {
            background-color: #343a40;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: #ddd !important;
            font-weight: bold;
        }
        .nav-link:hover {
            color: #fff !important;
        }

        /* Background Styling */
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('../uploads/mainbg.jpg') no-repeat center center;
            background-size: cover;
            color: #fff;
        }

        /* Card Styling */
        .card {
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        .btn-block {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .alert {
            font-weight: bold;
        }
        .star-rating {
            font-size: 1.5rem;
            color: gold;
        }

    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="../homepage.php">
            <img src="../uploads/I-go_logo.jpg" alt="I-go Logo">
            <b><span class="ml-2">I-go Homestay</span></b>
        </a>
        <div class="ml-auto d-flex">
            <a class="nav-link" href="user_dashboard.php">Home</a>
            <a class="nav-link" href="../logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Review and Report Forms -->
    <div class="row">
        <div class="col-md-6">
            <div class="card p-4">
                <h3 class="text-dark">Submit a Review</h3>
                <?php if ($success_message): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php elseif ($error_message): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="form-group">
                        <label class="text-dark">Rating:</label>
                        <select name="rating" class="form-control" required>
                            <option value="5">★★★★★ (5)</option>
                            <option value="4">★★★★☆ (4)</option>
                            <option value="3">★★★☆☆ (3)</option>
                            <option value="2">★★☆☆☆ (2)</option>
                            <option value="1">★☆☆☆☆ (1)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="text-dark">Comment:</label>
                        <textarea name="review_comment" class="form-control" rows="3" placeholder="Write your review..." required></textarea>
                    </div>
                    <button type="submit" name="submit_review" class="btn btn-primary btn-block">Submit Review</button>
                </form>
            </div>
        </div>



    <!-- Display Reviews -->
    <div class="mt-5">
        <h2>All Reviews</h2>
        <?php if (!empty($reviews)): ?>
            <?php foreach ($reviews as $review): ?>
                <div class="card mb-3 p-3">
                    <div class="d-flex justify-content-between">
                        <h5 class="text-dark"><?php echo htmlspecialchars($review['username']); ?></h5>
                        <div class="star-rating">
                            <?php echo str_repeat("★", $review['rating']); ?>
                            <?php echo str_repeat("☆", 5 - $review['rating']); ?>
                        </div>
                    </div>
                    <p class="text-dark"><?php echo htmlspecialchars($review['comment']); ?></p>
                    <small class="text-muted">Submitted at: <?php echo htmlspecialchars($review['created_at']); ?></small>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No reviews have been submitted yet.</p>
        <?php endif; ?>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
