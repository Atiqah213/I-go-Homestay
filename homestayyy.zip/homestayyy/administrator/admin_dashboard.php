<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

// Initialize variables
$room_name = '';
$description = '';
$price_per_night = '';
$capacity = '';
$availability = '';
$error_message = '';
$success_message = '';
$rooms = [];

// Handle form submission for adding or deleting rooms
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_room'])) {
        $room_name = $_POST['room_name'];
        $description = $_POST['description'];
        $price_per_night = $_POST['price_per_night'];
        $capacity = $_POST['capacity'];
        $availability = $_POST['availability'] === '1' ? 1 : 0; // Availability as 1 or 0
        $admin_id = $_SESSION['admin_id']; // Admin ID from the session

        try {
            // Insert the room into the database
            $stmt = $conn->prepare("INSERT INTO rooms (admin_id, room_name, description, price_per_night, capacity, availability)
                                    VALUES (:admin_id, :room_name, :description, :price_per_night, :capacity, :availability)");
            $stmt->execute([
                'admin_id' => $admin_id,
                'room_name' => $room_name,
                'description' => $description,
                'price_per_night' => $price_per_night,
                'capacity' => $capacity,
                'availability' => $availability
            ]);

            $room_id = $conn->lastInsertId(); // Get the ID of the newly inserted room

            // Handle file uploads
            $target_dir = "../uploads/";
            foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {
                $image_name = basename($_FILES["images"]["name"][$key]);
                $target_file = $target_dir . $image_name;
                $image_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                if (!in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
                    $error_message = "Only JPG, JPEG, PNG, and GIF files are allowed for images.";
                } elseif (!move_uploaded_file($tmp_name, $target_file)) {
                    $error_message = "Failed to upload the image.";
                } else {
                    // Save the image path in the room_images table
                    $stmt = $conn->prepare("INSERT INTO room_images (room_id, image_path) VALUES (:room_id, :image_path)");
                    $stmt->execute([
                        'room_id' => $room_id,
                        'image_path' => $image_name
                    ]);
                }
            }

            $success_message = "Room added successfully!";
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    } elseif (isset($_POST['delete_room'])) {
        $room_id = $_POST['room_id'];
        try {
            // Delete the room
            $stmt = $conn->prepare("DELETE FROM rooms WHERE room_id = :room_id AND admin_id = :admin_id");
            $stmt->execute(['room_id' => $room_id, 'admin_id' => $_SESSION['admin_id']]);
            $success_message = "Room deleted successfully!";
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    }
}

// Fetch all rooms managed by the admin
try {
    $stmt = $conn->prepare("SELECT * FROM rooms WHERE admin_id = :admin_id");
    $stmt->execute(['admin_id' => $_SESSION['admin_id']]);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Manage Rooms</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Navbar Styling */
        .navbar-brand img {
            height: 50px;
        }
        .navbar {
            background-color: #343a40;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: #ddd !important;
            font-weight: bold;
        }
        .nav-link:hover {
            color: #fff !important;
        }

        /* Background Styling */
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('../uploads/inah.jpg') no-repeat center center;
            background-size: cover;
            color: #ffe6cc;
        }

        /* Card Styling */
        .card {
            background: rgb(89, 89, 89);
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-primary, .btn-warning, .btn-danger {
            font-weight: bold;
        }
		        /* Footer Styling */
        footer {
            background-color: #343a40;
            color: #ddd;
            padding: 10px 0;
            text-align: center;
        }
        footer a {
            color: #007bff;
            text-decoration: none;
        }
        footer a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="../homepage.php">
            <img src="../uploads/I-go_logo.jpg" alt="I-go Logo">
            <b><span class="ml-2">I-go Homestay</span></b>
        </a>
        <div class="ml-auto d-flex">
            <a class="nav-link" href="../logout.php">Logout</a>
            <a class="nav-link" href="admin_dashboard.php">Home</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h3 class="text-center">Manage Your Rooms</h3>

    <!-- Success and Error Messages -->
    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <!-- Add New Room Form -->
    <form method="POST" enctype="multipart/form-data" class="mb-4">
        <div class="card p-4">
            <h5>Add a New Room</h5>
            <div class="form-group">
                <label for="room_name">Room Name</label>
                <input type="text" class="form-control" id="room_name" name="room_name" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" name="description" required></textarea>
            </div>
            <div class="form-group">
                <label for="price_per_night">Price per Night</label>
                <input type="number" class="form-control" id="price_per_night" name="price_per_night" required>
            </div>
            <div class="form-group">
                <label for="capacity">Capacity</label>
                <input type="number" class="form-control" id="capacity" name="capacity" required>
            </div>
            <div class="form-group">
                <label for="images">Room Images</label>
                <input type="file" class="form-control-file" id="images" name="images[]" multiple required>
            </div>
            <div class="form-group">
                <label for="availability">Availability</label>
                <select class="form-control" id="availability" name="availability" required>
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>
            </div>
            <button type="submit" name="add_room" class="btn btn-primary btn-block">Add Room</button>
        </div>
    </form>

    <!-- Display Existing Rooms -->
    <h5>Your Rooms</h5>
    <table class="table table-bordered text-white">
        <thead>
            <tr>
                <th>Room Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Capacity</th>
                <th>Availability</th>
                <th>Images</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($rooms)): ?>
                <?php foreach ($rooms as $room): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($room['room_name']); ?></td>
                        <td><?php echo htmlspecialchars($room['description']); ?></td>
                        <td><?php echo htmlspecialchars($room['price_per_night']); ?></td>
                        <td><?php echo htmlspecialchars($room['capacity']); ?></td>
                        <td><?php echo $room['availability'] ? 'Yes' : 'No'; ?></td>
                        <td>
                            <?php
                            $stmt = $conn->prepare("SELECT image_path FROM room_images WHERE room_id = :room_id");
                            $stmt->execute(['room_id' => $room['room_id']]);
                            $images = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($images as $image) {
                                echo '<img src="../uploads/' . htmlspecialchars($image['image_path']) . '" alt="Room Image" width="100">';
                            }
                            ?>
                        </td>
                        <td>
                            <a href="update_rooms.php?room_id=<?php echo $room['room_id']; ?>" class="btn btn-warning btn-sm">Update</a>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                                <button type="submit" name="delete_room" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No rooms available.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<!-- Footer -->
<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> I-go Homestay. All rights reserved. | <a href="privacy-policy.php">Privacy Policy</a></p>
    </div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
