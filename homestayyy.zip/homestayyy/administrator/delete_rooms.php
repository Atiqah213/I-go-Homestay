<?php
session_start();
require_once '../db.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

if (isset($_GET['room_id'])) {
    $room_id = $_GET['room_id'];

    try {
        // Delete the room
        $stmt = $conn->prepare("DELETE FROM rooms WHERE room_id = :room_id AND admin_id = :admin_id");
        $stmt->execute(['room_id' => $room_id, 'admin_id' => $_SESSION['admin_id']]);

        // Redirect with success message
        echo "<script>
            alert('Room deleted successfully!');
            window.location.href = 'add_rooms.php';
        </script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>
            alert('Error: Unable to delete room. " . $e->getMessage() . "');
            window.location.href = 'add_rooms.php';
        </script>";
        exit;
    }
} else {
    header("Location: add_rooms.php");
    exit;
}
?>
