<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

// Initialize variables
$room_name = '';
$description = '';
$price_per_night = '';
$capacity = '';
$availability = '';
$error_message = '';
$success_message = '';
$rooms = []; // Initialize $rooms as an empty array

// Handle form submission for adding or deleting rooms
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_room'])) {
        $room_name = $_POST['room_name'];
        $description = $_POST['description'];
        $price_per_night = $_POST['price_per_night'];
        $capacity = $_POST['capacity'];
        $availability = isset($_POST['availability']) ? 1 : 0;
        $admin_id = $_SESSION['admin_id']; // Admin ID from the session

        // Handle file upload for images
        $target_dir = "../uploads/";
        $image_name = basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $image_name;
        $image_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        // Validate the form
        if (empty($room_name) || empty($description) || empty($price_per_night) || empty($capacity)) {
            $error_message = "All fields are required.";
        } elseif (!in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
            $error_message = "Only JPG, JPEG, PNG, and GIF files are allowed for images.";
        } elseif (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $error_message = "Failed to upload the image.";
        } else {
            try {
                $stmt = $conn->prepare("INSERT INTO rooms (admin_id, room_name, description, price_per_night, capacity, images, availability)
                                        VALUES (:admin_id, :room_name, :description, :price_per_night, :capacity, :images, :availability)");
                $stmt->execute([
                    'admin_id' => $admin_id,
                    'room_name' => $room_name,
                    'description' => $description,
                    'price_per_night' => $price_per_night,
                    'capacity' => $capacity,
                    'images' => $image_name,
                    'availability' => $availability
                ]);
                $success_message = "Room added successfully!";
            } catch (PDOException $e) {
                $error_message = "Error: " . $e->getMessage();
                error_log($error_message, 3, "../logs/error_log.log");
            }
        }
    } elseif (isset($_POST['delete_room'])) {
        $room_id = $_POST['room_id'];
        try {
            $stmt = $conn->prepare("DELETE FROM rooms WHERE room_id = :room_id AND admin_id = :admin_id");
            $stmt->execute(['room_id' => $room_id, 'admin_id' => $_SESSION['admin_id']]);
            $success_message = "Room deleted successfully!";
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    }
}

// Fetch all rooms managed by the admin
try {
    $stmt = $conn->prepare("SELECT * FROM rooms WHERE admin_id = :admin_id");
    $stmt->execute(['admin_id' => $_SESSION['admin_id']]);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = "Error: " . $e->getMessage();
}
?>
