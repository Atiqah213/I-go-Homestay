<?php
session_start();
require_once '../db.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

// Initialize variables
$error_message = '';
$success_message = '';

// Fetch the room details
if (isset($_GET['room_id'])) {
    $room_id = $_GET['room_id'];

    try {
        $stmt = $conn->prepare("SELECT * FROM rooms WHERE room_id = :room_id AND admin_id = :admin_id");
        $stmt->execute(['room_id' => $room_id, 'admin_id' => $_SESSION['admin_id']]);
        $room = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$room) {
            $error_message = "Room not found or you do not have permission to edit this room.";
        }
    } catch (PDOException $e) {
        $error_message = "Error: " . $e->getMessage();
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room_id = $_POST['room_id'];
    $room_name = $_POST['room_name'];
    $description = $_POST['description'];
    $price_per_night = $_POST['price_per_night'];
    $capacity = $_POST['capacity'];
    $availability = isset($_POST['availability']) ? 1 : 0;

    try {
        // Update the room details
        $stmt = $conn->prepare("UPDATE rooms SET room_name = :room_name, description = :description, 
                                price_per_night = :price_per_night, capacity = :capacity, availability = :availability 
                                WHERE room_id = :room_id AND admin_id = :admin_id");
        $stmt->execute([
            'room_name' => $room_name,
            'description' => $description,
            'price_per_night' => $price_per_night,
            'capacity' => $capacity,
            'availability' => $availability,
            'room_id' => $room_id,
            'admin_id' => $_SESSION['admin_id']
        ]);

        $success_message = "Room updated successfully!";
    } catch (PDOException $e) {
        $error_message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Room</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h3>Update Room</h3>

    <!-- Success and Error Messages -->
    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <?php if (!empty($room)): ?>
        <form method="POST">
            <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($room['room_id']); ?>">
            <div class="form-group">
                <label for="room_name">Room Name</label>
                <input type="text" class="form-control" id="room_name" name="room_name" value="<?php echo htmlspecialchars($room['room_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" name="description" required><?php echo htmlspecialchars($room['description']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="price_per_night">Price per Night</label>
                <input type="number" class="form-control" id="price_per_night" name="price_per_night" value="<?php echo htmlspecialchars($room['price_per_night']); ?>" required>
            </div>
            <div class="form-group">
                <label for="capacity">Capacity</label>
                <input type="number" class="form-control" id="capacity" name="capacity" value="<?php echo htmlspecialchars($room['capacity']); ?>" required>
            </div>
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="availability" name="availability" <?php echo $room['availability'] ? 'checked' : ''; ?>>
                <label class="form-check-label" for="availability">Available</label>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Update Room</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
