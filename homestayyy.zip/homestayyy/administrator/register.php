<?php
require_once '../db.php'; // Use __DIR__ to correctly reference db.php

// Initialize variables
$username = '';
$password = '';
$email = '';
$error_message = '';
$success_message = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $email = $_POST["email"];

    // Basic validation
    if (empty($username) || empty($password) || empty($email)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email address.";
    } else {
        try {
            // Check if the username or email already exists
            $stmt = $conn->prepare("SELECT COUNT(*) FROM admin WHERE username = :username OR email = :email");
            $stmt->execute(['username' => $username, 'email' => $email]);
            if ($stmt->fetchColumn() > 0) {
                $error_message = "Username or email already exists.";
            } else {
                // Hash the password securely
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Insert the new admin into the database
                $stmt = $conn->prepare("INSERT INTO admin (username, password, email) VALUES (:username, :password, :email)");
                $stmt->execute([
                    'username' => $username,
                    'password' => $hashed_password,
                    'email' => $email
                ]);

                // Success message with JavaScript pop-up and redirection
                echo "<script>
                    alert('Registration successful! Redirecting to login page...');
                    window.location.href = '../login.php';
                </script>";
                exit;
            }
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Navbar Styling */
        .navbar-brand img {
            height: 50px;
        }
        .navbar {
            background-color: #343a40;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: #ddd !important;
            font-weight: bold;
        }
        .nav-link:hover {
            color: #fff !important;
        }

        /* Background Styling */
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('../uploads/mainbg.jpg') no-repeat center center;
            background-size: cover;
            color: #fff;
        }

        /* Card Styling */
        .card {
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        .btn-block {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .alert {
            font-weight: bold;
        }
		        /* Footer Styling */
        footer {
            background-color: #343a40;
            color: #ddd;
            padding: 10px 0;
            text-align: center;
        }
        footer a {
            color: #007bff;
            text-decoration: none;
        }
        footer a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="../homepage.php">
            <img src="../uploads/I-go_logo.jpg" alt="I-go Logo">
            <b><span class="ml-2">I-go Homestay</span></b>
        </a>
        <div class="ml-auto d-flex">
            <a class="nav-link" href="../login.php">Login</a>
            <a class="nav-link" href="register.php">Register</a>
        </div>
    </div>
</nav>

<!-- Registration Form -->
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-body">
                    <h3 class="text-center text-dark">Admin Registration</h3>

                    <!-- Display success or error messages -->
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="form-group">
                            <label for="username" class="text-dark">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="password" class="text-dark">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="email" class="text-dark">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
                    </form>

                    <div class="text-center mt-3">
                        <p class="text-dark">Already have an account? <a href="../login.php">Login here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> I-go Homestay. All rights reserved. | <a href="privacy-policy.php">Privacy Policy</a></p>
    </div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
