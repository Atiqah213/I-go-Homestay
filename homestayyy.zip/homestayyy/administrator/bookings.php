<?php
session_start();
require_once '../db.php'; // Include the database connection file

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    die("Error: Admin is not logged in.");
}

// Fetch all bookings
$bookings = [];
try {
    $stmt = $conn->prepare("SELECT b.*, r.room_name, u.username AS customer_name, u.email AS customer_email 
                            FROM bookings b 
                            JOIN rooms r ON b.room_id = r.room_id 
                            JOIN user u ON b.user_id = u.user_id");
    $stmt->execute();
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Bookings - I-go Homestay</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('../uploads/background.jpg') no-repeat center center;
            background-size: cover;
            color: #fff;
        }
        .navbar {
            background-color: #222;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand img {
            height: 50px;
        }
        .table {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            color: #254;
        }
        .badge {
            font-size: 0.9rem;
            padding: 0.5em;
        }
        .badge-success {
            background-color: #007bff;
        }
        .badge-danger {
            background-color: #dc3545;
        }
        .badge-warning {
            background-color: #ffc107;
        }
        .btn-group button {
            font-size: 0.8rem;
        }
        @media (max-width: 768px) {
            .btn-group button {
                font-size: 0.7rem;
            }
            .table td, .table th {
                font-size: 0.85rem;
            }
        }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="../homepage.php">
            <img src="../uploads/I-go_logo.jpg" alt="Logo">
            I-go Homestay
        </a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="admin_dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h3 class="text-center">Manage Bookings</h3>

    <!-- Bookings Table -->
    <div class="table-responsive mt-4">
        <table class="table table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Booking ID</th>
                    <th>Room Name</th>
                    <th>Customer Name</th>
                    <th>Customer Email</th>
                    <th>Check-In</th>
                    <th>Check-Out</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($bookings)): ?>
                    <?php foreach ($bookings as $booking): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($booking['booking_id']); ?></td>
                            <td><?php echo htmlspecialchars($booking['room_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['customer_email']); ?></td>
                            <td><?php echo htmlspecialchars($booking['check_in']); ?></td>
                            <td><?php echo htmlspecialchars($booking['check_out']); ?></td>
                            <td>RM<?php echo number_format($booking['total_price'], 2); ?></td>
                            <td>
                                <span class="badge badge-<?php echo $booking['status'] === 'Reserved' ? 'success' : ($booking['status'] === 'Not Available' ? 'danger' : 'warning'); ?>">
                                    <?php echo htmlspecialchars($booking['status']); ?>
                                </span>
                            </td>
                            <td>
                                <!-- Action Buttons -->
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-primary status-update"
                                            data-booking-id="<?php echo $booking['booking_id']; ?>"
                                            data-status="Reserved">Reserved</button>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center">No bookings found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).on('click', '.status-update', function () {
        const bookingId = $(this).data('booking-id');
        const status = $(this).data('status');

        $.ajax({
            url: 'update_status.php',
            type: 'POST',
            data: { booking_id: bookingId, status: status },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    alert(response.message);
                    location.reload(); // Reload the page to reflect changes
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function () {
                alert('An error occurred while updating the status.');
            }
        });
    });
	

</script>
</body>
</html>
