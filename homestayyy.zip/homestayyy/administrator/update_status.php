<?php
require_once '../db.php'; // Include the database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['booking_id'], $_POST['status'])) {
        $booking_id = $_POST['booking_id'];
        $status = $_POST['status'];

        try {
            // Update the booking status in the database
            $stmt = $conn->prepare("UPDATE bookings SET status = :status WHERE booking_id = :booking_id");
            $stmt->execute(['status' => $status, 'booking_id' => $booking_id]);

            echo json_encode(['success' => true, 'message' => 'Booking status updated successfully.']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid input data.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
