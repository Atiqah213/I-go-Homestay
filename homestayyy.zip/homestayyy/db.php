<?php
$host = 'localhost';       // Database host
$username = 'root';        // Database username
$password = '';            // Database password (leave blank for XAMPP default)
$dbname = 'homestay_system'; // Your database name

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
