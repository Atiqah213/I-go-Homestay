<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage - I-go Homestay</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Navbar Styling */
        .navbar-brand img {
            height: 50px;
        }
        .navbar {
            background-color: #343a40;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: #ddd !important;
            font-weight: bold;
        }
        .nav-link:hover {
            color: #fff !important;
        }
        .nav-item {
            margin-left: 20px;
        }

        /* Hero Section Styling */
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('uploads/mainbg.jpg') no-repeat center center;
            background-size: cover;
            height: 85vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #fff;
            text-align: center;
            padding: 20px;
        }
        .hero-section h1 {
            font-weight: bold;
            font-size: 3.5rem;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.5rem;
            margin-bottom: 30px;
        }
        .hero-section a {
            color: #fff;
            text-decoration: underline;
            font-weight: bold;
        }
        .hero-section a:hover {
            color: #007bff;
            text-decoration: none;
        }

        /* Footer Styling */
        footer {
            background-color: #343a40;
            color: #ddd;
            padding: 10px 0;
            text-align: center;
        }
        footer a {
            color: #007bff;
            text-decoration: none;
        }
        footer a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="uploads/I-go_logo.jpg" alt="I-go Logo">
            <b><span class="ml-2">I-go Homestay</span></b>
        </a>
        <div class="ml-auto d-flex">
            <a class="nav-link" href="login.php">Login</a>
            <a class="nav-link nav-item" href="user/register.php">Register</a>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<div class="hero-section">
    <h1>WELCOME TO I-go Homestay</h1>
    <p>Find your perfect stay! Please register to book your desired rooms today.</p>
    <a href="user/register.php" class="btn btn-primary btn-lg">Get Started</a>

    <!-- Map Section -->
    <div class="map-container mt-5" style="width: 400px; height: 300px; margin: 0 auto; position: relative;">
        <!-- Embed Google Map -->
        <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31871.89067323311!2d101.5661216!3d3.0959761!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc4f07d1bd41f5%3A0x9a3197c3280b57f3!2sI-go%20Homestay!5e0!3m2!1sen!2smy!4v1699723149385!5m2!1sen!2smy" 
            width="400" 
            height="300" 
            style="border:0; border-radius: 8px;"
            allowfullscreen="" 
            loading="lazy">
        </iframe>

        <!-- "Show on Map" Button -->
        <button 
            onclick="window.open('https://www.google.com/maps?q=I-go+Homestay', '_blank')" 
            style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #007bff; color: white; border: none; border-radius: 5px; padding: 8px 12px; cursor: pointer;">
            Show on Map
        </button>
    </div>
</div>




<!-- Footer -->
<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> I-go Homestay. All rights reserved. | <a href="privacy-policy.php">Privacy Policy</a></p>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
