<?php
session_start();
include 'db.php'; // Include the correct PDO database connection file

// Check if the user submitted the login form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the user's credentials from the form
    $username = $_POST["username"];
    $password = $_POST["password"];
    $error_message = '';

    try {
        // Check if the user exists in the admin table
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            // Verify the hashed password for admin
            if (password_verify($password, $admin['password'])) {
                // Set session variables for the admin
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['username'] = $admin['username'];
                $_SESSION['role'] = 'admin';
                header("Location: administrator/admin_dashboard.php"); // Admin Dashboard
                exit;
            } else {
                $error_message = "Invalid username or password.";
            }
        } else {
            // Check if the user exists in the user table
            $stmt = $conn->prepare("SELECT * FROM user WHERE username = :username");
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Verify the hashed password for user
                if (password_verify($password, $user['password'])) {
                    // Check the role and redirect accordingly
                    if ($user['role'] === 'owner') {
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = 'owner';
                        $_SESSION['user_id'] = $user['user_id'];
                        header("Location: administrator/admin_dashboard.php"); // Admin Dashboard
                        exit;
                    } elseif ($user['role'] === 'customer') {
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = 'customer';
                        $_SESSION['user_id'] = $user['user_id'];
                        header("Location: user/user_dashboard.php"); // User Dashboard
                        exit;
                    }
                } else {
                    $error_message = "Invalid username or password.";
                }
            } else {
                $error_message = "Invalid username or password.";
            }
        }
    } catch (PDOException $e) {
        $error_message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - I-go Homestay</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Navbar Styling */
        .navbar-brand img {
            height: 50px;
        }
        .navbar {
            background-color: #343a40;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .nav-link {
            color: #ddd !important;
            font-weight: bold;
        }
        .nav-link:hover {
            color: #fff !important;
        }
        .nav-item {
            margin-left: 20px;
        }

        /* Background Styling */
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('uploads/mainbg.jpg') no-repeat center center;
            background-size: cover;
            color: #fff;
        }

        /* Card Styling */
        .card {
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        .btn-block {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .alert {
            font-weight: bold;
        }
		        /* Footer Styling */
        footer {
            background-color: #343a40;
            color: #ddd;
            padding: 10px 0;
            text-align: center;
        }
        footer a {
            color: #007bff;
            text-decoration: none;
        }
        footer a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
    </style>
</head>
<body>


<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="../homepage.php">
            <img src="uploads/I-go_logo.jpg" alt="Logo">
            <b><span class="ml-2">I-go Homestay</span></b>
        </a>
        <div class="ml-auto d-flex">
            <a class="nav-link" href="http://localhost/homestayyy/homepage.php">Home</a>
            <a class="nav-link" href="user/register.php">Register</a>
        </div>
    </div>
</nav>


<!-- Login Form -->
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-body">
                    <h3 class="text-center text-dark">Login</h3>

                    <!-- Display error message if login fails -->
                    <?php if (isset($error_message)) { ?>
                        <div class="alert alert-danger mt-3" role="alert">
                            <?php echo $error_message; ?>
                        </div>
                    <?php } ?>

                    <form method="POST">
                        <div class="form-group">
                            <label for="username" class="text-dark">Username</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
                        </div>
                        <div class="form-group">
                            <label for="password" class="text-dark">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Login</button>
                    </form>

                    <div class="text-center mt-3">
                        <p class="text-dark">Don't have an account? <a href="user/register.php">Register here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

	<!-- Footer -->
<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> I-go Homestay. All rights reserved. | <a href="privacy-policy.php">Privacy Policy</a></p>
    </div>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
